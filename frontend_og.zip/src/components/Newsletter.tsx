import React from 'react';

export default function Newsletter() {
  return (
    <section className="py-24 bg-stone-50 border-t border-neutral-200 mt-10">
      <div className="max-w-3xl mx-auto px-4 text-center">
        <h2 className="text-2xl font-semibold tracking-widest uppercase mb-4">Únete a nuestro universo</h2>
        <p className="text-neutral-500 mb-8 max-w-lg mx-auto text-sm">
          Suscríbete y recibe novedades de nuestras colecciones, piezas exclusivas y un 10% de descuento en tu primera compra.
        </p>
        
        <form className="flex flex-col sm:flex-row gap-0 max-w-xl mx-auto" onSubmit={(e) => e.preventDefault()}>
          <input 
            type="email" 
            placeholder="Tu correo electrónico" 
            className="flex-1 bg-transparent border-b border-black py-4 px-2 focus:outline-none placeholder-neutral-400 text-sm"
            required
          />
          <button 
            type="submit" 
            className="bg-black text-white px-8 py-4 text-xs tracking-widest uppercase font-medium hover:bg-neutral-800 transition-colors sm:ml-4 mt-4 sm:mt-0"
          >
            Suscribirme
          </button>
        </form>
        <p className="text-[#a0a0a0] text-[10px] mt-6 text-center">
          Al suscribirte aceptas nuestros Términos y Condiciones y Política de Privacidad.
        </p>
      </div>
    </section>
  );
}
